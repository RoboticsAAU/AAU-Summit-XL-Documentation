#ifndef __SERVICE_COMPONENT__
#define __SERVICE_COMPONENT__

#include <ros/ros.h>

#include <service_shifter/service_shifter.h>

#include <boost/bind.hpp>
#include <boost/any.hpp>

namespace service_shifter
{
// GenericShifterServiceServer is a class without a type that it is
// then specialized with templates. It is necessary to create a
// collection of templated objects.

class GenericShifterServiceServer
{
public:
  // required by the pluginlib
  GenericShifterServiceServer()
  {
  }
  virtual ~GenericShifterServiceServer()
  {
  }

  // from the ShifterServiceServer. Add this methods as pure virtuals in case we need to access them from this class
  ros::AdvertiseServiceOptions getServiceOptions()
  {
    return service_options_;
  }
  void setServiceName(std::string name)
  {
    service_options_.service = name;
  }
  // this method is needed to get the pointer to the bridgeServiceCallback function.
  // the real bridgeServiceCallback needs to know the real type, so it is implemented in the specialized class
  virtual boost::function<bool(const service_shifter::ServiceShifter&, service_shifter::ServiceShifter&)>
  getBridgeServiceCallbackFunction() = 0;

  // this method is needed to call it from a GenericShifterServiceServer
  // as is pure virtual because we need to know the real type in the implementation
  virtual void registerServiceCallback(boost::any serviceCallback) = 0;

  // classes to advertise the service from here
  // TODO: this method conflicts with the one below, because type boost::function is ambiguous wiht the number of
  // paramaters
  // maybe using templates, such as boost::function<T> and the other boost::function<T, S>, but not really sure
  //  ros::ServiceServer advertiseService(
  //      ros::NodeHandle& nh,
  //      boost::function<bool(ros::ServiceEvent<service_shifter::ServiceShifter, service_shifter::ServiceShifter>)>
  //          callback)
  //  {
  //    service_options_.helper = boost::make_shared<ros::ServiceCallbackHelperT<
  //        ros::ServiceEvent<service_shifter::ServiceShifter, service_shifter::ServiceShifter> > >(callback);
  //
  //    return nh.advertiseService(service_options_);
  //  }

  /// This advertiseServiceServer have been commented out, because it wasn't clear their behaviour.
  /// They received a function that accepted a ServiceEvent and a function pointer, then it was binded so the
  /// function pointer was the bridgeServiceCallback.
  /// But this is strange, as we are binding an external function inside this class.
  /// So now it has been changed, and the binding is done in the outside, and the function received only has
  /// and argument of type ServiceEvent

  ///  ros::ServiceServer
  ///  advertiseService(ros::NodeHandle& nh,
  ///                   boost::function<bool(
  ///                       const ros::ServiceEvent<service_shifter::ServiceShifter, service_shifter::ServiceShifter>&
  ///                       event,
  ///                       boost::function<bool(const service_shifter::ServiceShifter&,
  ///                       service_shifter::ServiceShifter&)>)>
  ///                       callback)
  ///  {
  ///    service_options_.helper = boost::make_shared<ros::ServiceCallbackHelperT<
  ///        ros::ServiceEvent<service_shifter::ServiceShifter, service_shifter::ServiceShifter> > >(
  ///
  ///        boost::bind(callback, _1, this->getBridgeServiceCallbackFunction()));
  ///
  ///    return nh.advertiseService(service_options_);
  ///  }
  ///
  ///  ros::ServiceServer advertiseService(
  ///      ros::NodeHandle& nh,
  ///      bool (*callback)(const ros::ServiceEvent<service_shifter::ServiceShifter, service_shifter::ServiceShifter>&
  ///      event,
  ///                       boost::function<bool(const service_shifter::ServiceShifter&,
  ///                       service_shifter::ServiceShifter&)>))
  ///  {
  ///    service_options_.helper = boost::make_shared<ros::ServiceCallbackHelperT<
  ///        ros::ServiceEvent<service_shifter::ServiceShifter, service_shifter::ServiceShifter> > >(
  ///
  ///        boost::bind(callback, _1, this->getBridgeServiceCallbackFunction()));
  ///
  ///    return nh.advertiseService(service_options_);
  ///  }
  ///
  ///  template <class O>
  ///  ros::ServiceServer
  ///  advertiseService(ros::NodeHandle& nh,
  ///                   bool (O::*callback)(
  ///                       const ros::ServiceEvent<service_shifter::ServiceShifter, service_shifter::ServiceShifter>&
  ///                       event,
  ///                       boost::function<bool(const service_shifter::ServiceShifter&,
  ///                       service_shifter::ServiceShifter&)>),
  ///                   O* obj)
  ///  {
  ///    service_options_.helper = boost::make_shared<ros::ServiceCallbackHelperT<
  ///        ros::ServiceEvent<service_shifter::ServiceShifter, service_shifter::ServiceShifter> > >(
  ///        boost::bind(callback, obj, _1, this->getBridgeServiceCallbackFunction()));
  ///
  ///    return nh.advertiseService(service_options_);
  ///  }

  ros::ServiceServer advertiseService(
      ros::NodeHandle& nh,
      boost::function<
          bool(const ros::ServiceEvent<service_shifter::ServiceShifter, service_shifter::ServiceShifter>& event)>
          callback)
  {
    service_options_.helper = boost::make_shared<ros::ServiceCallbackHelperT<
        ros::ServiceEvent<service_shifter::ServiceShifter, service_shifter::ServiceShifter> > >(callback);

    return nh.advertiseService(service_options_);
  }

protected:
  ros::AdvertiseServiceOptions service_options_;
};

template <class T>
class ShifterServiceServer : public GenericShifterServiceServer
{
public:
  ShifterServiceServer()
  {
    this->setServiceName(ros::message_traits::DataType<typename T::Request>::value());

    service_options_.datatype = ros::service_traits::DataType<T>::value();
    service_options_.md5sum = ros::service_traits::MD5Sum<T>::value();
    service_options_.req_datatype = ros::message_traits::DataType<typename T::Request>::value();
    service_options_.res_datatype = ros::message_traits::DataType<typename T::Response>::value();
  }

  virtual ~ShifterServiceServer()
  {
  }

  // this function is the one called as callback, to convert from ServiceShifter to the ServiceType
  // this function should never change nor overloaded
  bool bridgeServiceCallback(const service_shifter::ServiceShifter& request, service_shifter::ServiceShifter& response)
  {
    // the following assignments are required due to some type of internal constructor/destructor calling
    const typename T::Request req = request;
    typename T::Response res = response;

    // serviceCallback(req, res);
    if (serviceCallback == 0)
    {
      ROS_ERROR("Not registered!");  // add a better error management
      response = res;
      return false;
    }
    else
    {
      bool callback_result = serviceCallback(req, res);
      response = res;
      return callback_result;
    }
  }

  // maybe typedef the service call, it is too long!
  // this function returns a boost::function so we can call bridgeServiceCallback from this instance without having the
  // pointer to the instance
  boost::function<bool(const service_shifter::ServiceShifter&, service_shifter::ServiceShifter&)>
  getBridgeServiceCallbackFunction()
  {
    return boost::bind(&ShifterServiceServer::bridgeServiceCallback, this, _1, _2);
  }

  virtual void registerServiceCallback(boost::any sc)
  {
    this->serviceCallback = boost::any_cast<bool (*)(const typename T::Request&, typename T::Response&)>(sc);
  }

  // XXX: this function is left here just to remember how can we can register a function using the templated type
  virtual void
  registerBoostFunctionServiceCallback(boost::function<bool(const typename T::Request&, typename T::Response&)> sc)
  {
    this->serviceCallback = sc;
  }

protected:
  boost::function<bool(const typename T::Request&, typename T::Response&)> serviceCallback;
};

}  // namespace service_shifter

#endif  //__SERVICE_COMPONENT__
