#ifndef _ROBOTNIK_BASE_HW_TIME_COUNTER_
#define _ROBOTNIK_BASE_HW_TIME_COUNTER_

#include <ros/ros.h>

class TimeCounter
{
  ros::SteadyTime init_time_;
  ros::SteadyTime last_time_;
  bool started_;

public:
  TimeCounter()
  {
    started_ = false;
  }

  void tic()
  {
    started_ = true;
    init_time_ = ros::SteadyTime::now();
    last_time_ = init_time_;  // so secondsElapsed is 0 is toc is not called before
  }

  ros::WallDuration toc(bool auto_start = true)
  {
    if (started_ == false and auto_start == false)
    {
      return ros::WallDuration(0);
    }

    if (started_ == false and auto_start == true)
    {
      tic();
    }

    last_time_ = ros::SteadyTime::now();
    return last_time_ - init_time_;
  }

  double secondsElapsed()
  {
    if (started_ == false)
      return ros::WallDuration(0).toSec();

    return (last_time_ - init_time_).toSec();
  }

  void stop()
  {
    started_ = false;
  }

  bool running()
  {
    return started_;
  }
};

#endif  // _ROBOTNIK_BASE_HW_TIME_COUNTER_
