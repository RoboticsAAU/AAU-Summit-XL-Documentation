
"use strict";

let ChargePetition = require('./ChargePetition.js')
let GoToPetition = require('./GoToPetition.js')
let PrePickPetition = require('./PrePickPetition.js')
let EnterShowerPetition = require('./EnterShowerPetition.js')
let SwitchMapPetition = require('./SwitchMapPetition.js')
let FindMagneticGuidePetition = require('./FindMagneticGuidePetition.js')
let Cancel = require('./Cancel.js')
let PostPlacePetition = require('./PostPlacePetition.js')
let MagneticPlacePetition = require('./MagneticPlacePetition.js')
let StatusPetition = require('./StatusPetition.js')
let PickPetition = require('./PickPetition.js')
let SetElevatorPetition = require('./SetElevatorPetition.js')
let EnterLiftPetition = require('./EnterLiftPetition.js')
let MagneticNavigationPetition = require('./MagneticNavigationPetition.js')
let DockPetition = require('./DockPetition.js')
let SetControlState = require('./SetControlState.js')
let SimpleGoToWithValidation = require('./SimpleGoToWithValidation.js')
let MagneticGoToPetition = require('./MagneticGoToPetition.js')
let SetPose2DStamped = require('./SetPose2DStamped.js')
let MovePetition = require('./MovePetition.js')
let PrePlacePetition = require('./PrePlacePetition.js')
let PlacePetition = require('./PlacePetition.js')
let MissionCommandPetition = require('./MissionCommandPetition.js')
let MissionPetition = require('./MissionPetition.js')
let SaveMap = require('./SaveMap.js')
let GoToNodePetition = require('./GoToNodePetition.js')
let LeaveMagneticGuidePetition = require('./LeaveMagneticGuidePetition.js')
let PostPickPetition = require('./PostPickPetition.js')
let BatteryExchangePetition = require('./BatteryExchangePetition.js')
let GoToTagPetition = require('./GoToTagPetition.js')
let SetEnvironment = require('./SetEnvironment.js')
let SetFrameID = require('./SetFrameID.js')
let GoToGPSPetition = require('./GoToGPSPetition.js')
let UnchargePetition = require('./UnchargePetition.js')
let MagneticPickPetition = require('./MagneticPickPetition.js')
let SetGoToPetition = require('./SetGoToPetition.js')
let SwitchModule = require('./SwitchModule.js')
let LeaveShowerPetition = require('./LeaveShowerPetition.js')
let LeaveLiftPetition = require('./LeaveLiftPetition.js')
let GetEnvironment = require('./GetEnvironment.js')

module.exports = {
  ChargePetition: ChargePetition,
  GoToPetition: GoToPetition,
  PrePickPetition: PrePickPetition,
  EnterShowerPetition: EnterShowerPetition,
  SwitchMapPetition: SwitchMapPetition,
  FindMagneticGuidePetition: FindMagneticGuidePetition,
  Cancel: Cancel,
  PostPlacePetition: PostPlacePetition,
  MagneticPlacePetition: MagneticPlacePetition,
  StatusPetition: StatusPetition,
  PickPetition: PickPetition,
  SetElevatorPetition: SetElevatorPetition,
  EnterLiftPetition: EnterLiftPetition,
  MagneticNavigationPetition: MagneticNavigationPetition,
  DockPetition: DockPetition,
  SetControlState: SetControlState,
  SimpleGoToWithValidation: SimpleGoToWithValidation,
  MagneticGoToPetition: MagneticGoToPetition,
  SetPose2DStamped: SetPose2DStamped,
  MovePetition: MovePetition,
  PrePlacePetition: PrePlacePetition,
  PlacePetition: PlacePetition,
  MissionCommandPetition: MissionCommandPetition,
  MissionPetition: MissionPetition,
  SaveMap: SaveMap,
  GoToNodePetition: GoToNodePetition,
  LeaveMagneticGuidePetition: LeaveMagneticGuidePetition,
  PostPickPetition: PostPickPetition,
  BatteryExchangePetition: BatteryExchangePetition,
  GoToTagPetition: GoToTagPetition,
  SetEnvironment: SetEnvironment,
  SetFrameID: SetFrameID,
  GoToGPSPetition: GoToGPSPetition,
  UnchargePetition: UnchargePetition,
  MagneticPickPetition: MagneticPickPetition,
  SetGoToPetition: SetGoToPetition,
  SwitchModule: SwitchModule,
  LeaveShowerPetition: LeaveShowerPetition,
  LeaveLiftPetition: LeaveLiftPetition,
  GetEnvironment: GetEnvironment,
};
