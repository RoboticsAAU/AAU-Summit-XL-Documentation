
"use strict";

let StatusArray = require('./StatusArray.js');
let GoToNode = require('./GoToNode.js');
let PrePlace = require('./PrePlace.js');
let RobotStatus = require('./RobotStatus.js');
let MissionStatus = require('./MissionStatus.js');
let MagneticPick = require('./MagneticPick.js');
let Missions = require('./Missions.js');
let GoTo = require('./GoTo.js');
let LeaveShower = require('./LeaveShower.js');
let MagneticGoTo = require('./MagneticGoTo.js');
let PostPick = require('./PostPick.js');
let EnterShower = require('./EnterShower.js');
let Charge = require('./Charge.js');
let EnterLift = require('./EnterLift.js');
let Pose2DStamped = require('./Pose2DStamped.js');
let ControllerStatus = require('./ControllerStatus.js');
let MissionParamFloat = require('./MissionParamFloat.js');
let Twist2D = require('./Twist2D.js');
let Status = require('./Status.js');
let LeaveLift = require('./LeaveLift.js');
let SetElevator = require('./SetElevator.js');
let Pick = require('./Pick.js');
let Uncharge = require('./Uncharge.js');
let PrePick = require('./PrePick.js');
let MagneticNavigation = require('./MagneticNavigation.js');
let MissionCommand = require('./MissionCommand.js');
let Move = require('./Move.js');
let MissionParamInt = require('./MissionParamInt.js');
let PostPlace = require('./PostPlace.js');
let Dock = require('./Dock.js');
let SensorStatus = require('./SensorStatus.js');
let FindMagneticGuide = require('./FindMagneticGuide.js');
let MagneticPlace = require('./MagneticPlace.js');
let LeaveMagneticGuide = require('./LeaveMagneticGuide.js');
let GoToTag = require('./GoToTag.js');
let NavigationStatus = require('./NavigationStatus.js');
let PointGPS = require('./PointGPS.js');
let Place = require('./Place.js');
let MissionParamString = require('./MissionParamString.js');
let MissionParamBool = require('./MissionParamBool.js');
let SignalManager = require('./SignalManager.js');
let GoToGPS = require('./GoToGPS.js');
let SwitchMap = require('./SwitchMap.js');
let LocalizationStatus = require('./LocalizationStatus.js');

module.exports = {
  StatusArray: StatusArray,
  GoToNode: GoToNode,
  PrePlace: PrePlace,
  RobotStatus: RobotStatus,
  MissionStatus: MissionStatus,
  MagneticPick: MagneticPick,
  Missions: Missions,
  GoTo: GoTo,
  LeaveShower: LeaveShower,
  MagneticGoTo: MagneticGoTo,
  PostPick: PostPick,
  EnterShower: EnterShower,
  Charge: Charge,
  EnterLift: EnterLift,
  Pose2DStamped: Pose2DStamped,
  ControllerStatus: ControllerStatus,
  MissionParamFloat: MissionParamFloat,
  Twist2D: Twist2D,
  Status: Status,
  LeaveLift: LeaveLift,
  SetElevator: SetElevator,
  Pick: Pick,
  Uncharge: Uncharge,
  PrePick: PrePick,
  MagneticNavigation: MagneticNavigation,
  MissionCommand: MissionCommand,
  Move: Move,
  MissionParamInt: MissionParamInt,
  PostPlace: PostPlace,
  Dock: Dock,
  SensorStatus: SensorStatus,
  FindMagneticGuide: FindMagneticGuide,
  MagneticPlace: MagneticPlace,
  LeaveMagneticGuide: LeaveMagneticGuide,
  GoToTag: GoToTag,
  NavigationStatus: NavigationStatus,
  PointGPS: PointGPS,
  Place: Place,
  MissionParamString: MissionParamString,
  MissionParamBool: MissionParamBool,
  SignalManager: SignalManager,
  GoToGPS: GoToGPS,
  SwitchMap: SwitchMap,
  LocalizationStatus: LocalizationStatus,
};
