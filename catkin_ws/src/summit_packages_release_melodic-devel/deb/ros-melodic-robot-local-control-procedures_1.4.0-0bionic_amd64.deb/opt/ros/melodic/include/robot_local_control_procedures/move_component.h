#ifndef __PROCEDURE_COMPONENT_MOVE_H
#define __PROCEDURE_COMPONENT_MOVE_H

#include <procedures/procedure_component.h>

#include <procedures_msgs/ProcedureQuery.h>
#include <procedures_msgs/ProcedureHeader.h>
#include <procedures_msgs/ProcedureState.h>
#include <procedures_msgs/ProcedureResult.h>

#include <robot_local_control_msgs/Pose2DStamped.h>
#include <robot_local_control_msgs/Twist2D.h>
#include <robot_local_control_msgs/Move.h>
#include <robot_local_control_msgs/MovePetition.h>

#include <tf/transform_listener.h>

#include <boost/scoped_ptr.hpp>

#include <actionlib/client/simple_action_client.h>

#include <robotnik_navigation_msgs/MoveAction.h>
#include <geometry_msgs/Twist.h>

#include <regex>

struct MoveProcedure
{
  robot_local_control_msgs::Move procedure;
  procedures_msgs::ProcedureHeader header;
  procedures_msgs::ProcedureState state;

  typedef robot_local_control_msgs::Move Type;
  typedef robot_local_control_msgs::MovePetition Petition;
};
namespace procedures
{
class ProcedureComponentMove : public ProcedureComponent<MoveProcedure>
{
public:
  ProcedureComponentMove();
  ProcedureComponentMove(ros::NodeHandle h, std::string name = "MoveComponent");

  virtual bool addProcedure(const MoveProcedure::Petition::Request& request,
                            MoveProcedure::Petition::Response& response);

  virtual bool cancelProcedure(procedures_msgs::ProcedureQuery::Request& request,
                               procedures_msgs::ProcedureQuery::Response& response);

  virtual bool cancelAllProcedures(procedures_msgs::ProcedureQuery::Request& request,
                                   procedures_msgs::ProcedureQuery::Response& response);

  virtual bool cancelAllProcedures();

  void standbyState();
  void emergencyState();
  void readyState();
  void initState();

  void setDockComponent(procedures::GenericProcedureComponent::Ptr component);
  void setMoveComponent(procedures::GenericProcedureComponent::Ptr component);
  void moveStateCallback(const robotnik_msgs::State& state);

protected:
  virtual void rosReadParams();
  virtual int rosSetup();
  virtual int setup();

  void stopActionGoals();

  int current_step_;
  bool sent_;
  std::string action_namespace_;
  std::string move_state_topic_;
  std::regex target_matcher_;
  double x_distance_goal_, y_distance_goal_, theta_goal_;
  geometry_msgs::Twist maximum_velocity_goal_;

  robotnik_msgs::State move_action_server_state_;

  tf::TransformListener tf_listener_;

  ros::Subscriber move_state_sub_;

  boost::scoped_ptr<actionlib::SimpleActionClient<robotnik_navigation_msgs::MoveAction> > move_action_;
};
}  // namespace procedures
#endif  // __PROCEDURE_COMPONENT_MOVE_H
