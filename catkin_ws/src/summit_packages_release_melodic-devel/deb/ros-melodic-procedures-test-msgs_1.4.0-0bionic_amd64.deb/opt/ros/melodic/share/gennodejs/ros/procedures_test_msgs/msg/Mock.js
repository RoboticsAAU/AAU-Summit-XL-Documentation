// Auto-generated. Do not edit!

// (in-package procedures_test_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Mock {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.string = null;
    }
    else {
      if (initObj.hasOwnProperty('string')) {
        this.string = initObj.string
      }
      else {
        this.string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Mock
    // Serialize message field [string]
    bufferOffset = _serializer.string(obj.string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Mock
    let len;
    let data = new Mock(null);
    // Deserialize message field [string]
    data.string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.string.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'procedures_test_msgs/Mock';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '923dd8c946bcf1b66f509c36c23d7b88';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string string
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Mock(null);
    if (msg.string !== undefined) {
      resolved.string = msg.string;
    }
    else {
      resolved.string = ''
    }

    return resolved;
    }
};

module.exports = Mock;
