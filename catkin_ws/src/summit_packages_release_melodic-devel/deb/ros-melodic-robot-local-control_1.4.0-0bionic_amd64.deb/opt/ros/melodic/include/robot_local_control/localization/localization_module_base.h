#ifndef _ROBOT_LOCAL_CONTROL_LOCALIZATION_MODULE_BASE_
#define _ROBOT_LOCAL_CONTROL_LOCALIZATION_MODULE_BASE_

#include <ros/ros.h>

#include <tf/tf.h>
#include <tf/transform_listener.h>

#include <robot_local_control_msgs/LocalizationStatus.h>
#include <robot_local_control_msgs/Pose2DStamped.h>

#include <robot_local_control/robot_local_control_component.h>

namespace robot_local_control
{
class LocalizationModuleBase : public robot_local_control::RobotLocalControlComponent
{
public:
  LocalizationModuleBase(ros::NodeHandle h = ros::NodeHandle("~"), std::string name = "LocalizationModule")
    : robot_local_control::RobotLocalControlComponent(h, name)
  {
  }

  virtual ~LocalizationModuleBase()
  {
  }

  static inline std::string getBaseType()
  {
    return std::string("LocalizationModule");
  }

  virtual std::string getType()
  {
    return getBaseType();
  }

  virtual robot_local_control_msgs::LocalizationStatus getCurrentStatus() = 0;
};

}  // namespace
#endif  //_ROBOT_LOCAL_CONTROL_LOCALIZATION_MODULE_BASE_
