#ifndef _ROBOT_LOCAL_CONTROL_LOCALIZATION_COMPONENT_BASE_
#define _ROBOT_LOCAL_CONTROL_LOCALIZATION_COMPONENT_BASE_

#include <ros/ros.h>

#include <tf/tf.h>
#include <tf/transform_listener.h>

#include <robot_local_control_msgs/LocalizationStatus.h>
#include <robot_local_control_msgs/Pose2DStamped.h>

#include <robot_local_control/robot_local_control_component.h>

// this is connected because now it is not used
//#include <map_server_msgs/LoadMap.h>

namespace robot_local_control
{
class LocalizationComponentBase : public robot_local_control::RobotLocalControlComponent
{
public:
  LocalizationComponentBase(ros::NodeHandle h = ros::NodeHandle("~"), std::string name = "LocalizationComponent")
    : robot_local_control::RobotLocalControlComponent(h, name)
  {
  }

  virtual ~LocalizationComponentBase()
  {
  }

  static inline std::string getBaseType()
  {
    return std::string("LocalizationComponent");
  }

  virtual std::string getType()
  {
    return getBaseType();
  }

  virtual robot_local_control_msgs::LocalizationStatus getCurrentStatus() = 0;
};

}  // namespace
#endif  //_ROBOT_LOCAL_CONTROL_LOCALIZATION_COMPONENT_BASE_
