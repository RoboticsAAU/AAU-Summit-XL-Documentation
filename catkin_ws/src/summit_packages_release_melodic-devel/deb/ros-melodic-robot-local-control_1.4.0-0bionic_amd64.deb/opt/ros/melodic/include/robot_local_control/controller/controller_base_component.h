#ifndef _ROBOT_LOCAL_CONTROL_CONTROLLER_COMPONENT_BASE_
#define _ROBOT_LOCAL_CONTROL_CONTROLLER_COMPONENT_BASE_

#include <ros/ros.h>

#include <tf/tf.h>
#include <tf/transform_listener.h>

#include <robot_local_control/robot_local_control_component.h>

#include <robot_local_control_msgs/ControllerStatus.h>

namespace robot_local_control
{
class ControllerComponentBase : public robot_local_control::RobotLocalControlComponent
{
public:
  ControllerComponentBase(ros::NodeHandle h = ros::NodeHandle("~"), std::string name = "ControllerComponent")
  {
  }

  virtual ~ControllerComponentBase()
  {
  }

  static inline std::string getBaseType()
  {
    return std::string("ControllerComponent");
  }
  virtual std::string getType()
  {
    return getBaseType();
  }

  virtual robot_local_control_msgs::ControllerStatus getCurrentStatus() = 0;

protected:
};
}  // namespace
#endif  //_ROBOT_LOCAL_CONTROL_CONTROLLER_COMPONENT_BASE_
