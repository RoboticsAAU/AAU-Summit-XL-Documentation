
"use strict";

let GetPOI_params = require('./GetPOI_params.js')
let GetEnvironments = require('./GetEnvironments.js')
let GetPoseTrigger = require('./GetPoseTrigger.js')
let ReadPOIs = require('./ReadPOIs.js')
let AddPOIs = require('./AddPOIs.js')
let DeletePOI = require('./DeletePOI.js')
let AddPOI = require('./AddPOI.js')
let GetPOI = require('./GetPOI.js')
let AddPOI_params = require('./AddPOI_params.js')
let DeleteEnvironment = require('./DeleteEnvironment.js')
let GetPOIs = require('./GetPOIs.js')

module.exports = {
  GetPOI_params: GetPOI_params,
  GetEnvironments: GetEnvironments,
  GetPoseTrigger: GetPoseTrigger,
  ReadPOIs: ReadPOIs,
  AddPOIs: AddPOIs,
  DeletePOI: DeletePOI,
  AddPOI: AddPOI,
  GetPOI: GetPOI,
  AddPOI_params: AddPOI_params,
  DeleteEnvironment: DeleteEnvironment,
  GetPOIs: GetPOIs,
};
